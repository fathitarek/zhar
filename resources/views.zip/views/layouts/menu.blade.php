<li class="{{ Request::is('realStates*') ? 'active' : '' }}">
    <a href="{!! route('realStates.index') !!}"><i class="fa fa-edit"></i><span>Real States</span></a>
</li>

